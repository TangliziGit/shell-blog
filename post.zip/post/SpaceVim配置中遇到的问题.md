这是一个不断更新的随笔，若遇到SpaceVim配置问题时，会添加项

### 字体乱码（linux企鹅乱码，tabline图标乱码等）
```
git clone https://github.com/powerline/fonts
cd fonts
./install.sh
```
然后选择xxx for powerline字体作为终端字体

### neomake调用clang-check默认查找compilatoin database
相见[[Debug]SpaceVim中neomake报错 Error while trying to load a compilation database](https://www.cnblogs.com/tanglizi/p/9333383.html)