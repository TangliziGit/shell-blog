# Welcome
This is a simple static blog based on `nginx` and `shell-scrpits`.

